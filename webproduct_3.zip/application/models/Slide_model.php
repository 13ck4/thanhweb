<?php 
	Class Slide_model extends MY_Model{
		var $table = 'slide';
	}