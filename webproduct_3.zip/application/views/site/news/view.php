
<style type="text/css">
  body{font-family:Roboto, sans-serif; font-weight:normal; }
  h1{font-family:Roboto, sans-serif; font-weight:100; }
  #sp-header-top{ background-color:#ffffff; }
  #sp-breadcrumb-block{ background-image:url("/demo/senvietdeal/images/bg-bredum.png");background-color:#f6f6f6; }
  #sp-block-acymailling{ background-color:#ffffff; }
  #sp-block-bottom-2{ background-color:#ffffff; }
  #sp-footer{ background-color:#060d11; }
  div.mod_search35 input[type="search"]{ width:auto; }
</style> 

<section id="sp-breadcrumb-block"><div class="container"><div class="row"><div id="sp-breadcrumb" class="col-sm-12 col-md-12"><div class="sp-column "><div class="sp-module "><div class="sp-module-content">
<ol class="breadcrumb">
  
  <li><a href="<?php echo base_url()?>" class="pathway">Home</a></li>
  <li class="active"><?=$news->title?></li></ol>
</div></div></div></div></div></div></section>



<section id="sp-main-body"><div class="container"><div class="row"><div id="sp-component" class="col-sm-12 col-md-12"><div class="sp-column "><div id="system-message-container">
  </div>
<article class="item item-page" itemscope="" itemtype="http://schema.org/Article">
  <meta itemprop="inLanguage" content="en-GB">
    <div class="entry-image full-image"> <img src="<?php echo base_url('/upload/news/'.$news->image_link)?>" alt="<?=$news->title?>" title="<?=$news->title?>"> </div>
      <div class="entry-header">
        <!-- <dl class="article-info">
          <dt class="article-info-term"></dt> 
            <dd class="category-name">
                  Danh mục sản phẩm       
                  <a href="/demo/senvietdeal/index.php/tin-tuc-su-kien.html" itemprop="genre" title="Article Category">Blog</a> </dd>                   <dd class="createdby" itemprop="author" itemscope="" itemtype="http://schema.org/Person">
                    Author:        
                     <span itemprop="name" title="Written by ">Super User</span> 
                    </dd>
                    <dd class="hits">
                    <meta itemprop="interactionCount" content="UserPageVisits:253">
                    Hits: 253</dd>          
    

            </dl> -->
    
          <h2 itemprop="name"><?=$news->title?>             </h2>
        </div>

        
    <!-- <div class="content_rating" itemprop="aggregateRating" itemscope="" itemtype="https://schema.org/AggregateRating">
  <p class="unseen element-invisible">
    User Rating:&nbsp;<span itemprop="ratingValue">5</span>&nbsp;/&nbsp;<span itemprop="bestRating">5</span>    <meta itemprop="ratingCount" content="1">
    <meta itemprop="worstRating" content="0">
  </p>
  <img src="/demo/senvietdeal/media/system/images/rating_star.png" alt="Star Active"><img src="/demo/senvietdeal/media/system/images/rating_star.png" alt="Star Active"><img src="/demo/senvietdeal/media/system/images/rating_star.png" alt="Star Active"><img src="/demo/senvietdeal/media/system/images/rating_star.png" alt="Star Active"><img src="/demo/senvietdeal/media/system/images/rating_star.png" alt="Star Active"></div>
<form method="post" action="http://senvietweb.com/demo/senvietdeal/index.php/huong-dan-thanh-toan/post-formats/standard-post-format.html?hitcount=0" class="form-inline">
  <span class="content_vote">
    <label class="unseen element-invisible" for="content_vote_'73">Please Rate</label>
    <select id="content_vote_73" name="user_rating">
  <option value="1">Vote 1</option>
  <option value="2">Vote 2</option>
  <option value="3">Vote 3</option>
  <option value="4">Vote 4</option>
  <option value="5" selected="selected">Vote 5</option>
</select>
    &nbsp;<input class="btn btn-mini" type="submit" name="submit_vote" value="Rate">
    <input type="hidden" name="task" value="article.vote">
    <input type="hidden" name="hitcount" value="0">
    <input type="hidden" name="url" value="http://senvietweb.com/demo/senvietdeal/index.php/huong-dan-thanh-toan/post-formats/standard-post-format.html?hitcount=0">
    <input type="hidden" name="4e84869e2f3831fb5522378aed9a8921" value="1"> </span>
</form> -->
        
  
      <div itemprop="articleBody">
          <p><?=$news->content?></p>
      </div>

  
  
  
<!-- <ul class="pager pagenav">
  <li class="previous">
    <a href="/demo/senvietdeal/index.php/huong-dan-thanh-toan/post-formats/video-post-format.html" rel="prev">
      <span class="icon-chevron-left"></span> Prev    </a>
  </li>
  <li class="next">
    <a href="/demo/senvietdeal/index.php/tin-tuc-su-kien/74-meatball-kevin-beef-ribs-shoulder.html" rel="next">
      Next <span class="icon-chevron-right"></span>   </a>
  </li>
</ul> -->
        
  
  
      <!-- <div class="article-footer-wrap">
      <div class="article-footer-top">
          <dd class="post_rating" id="post_vote_73">
    Rating: <div class="voting-symbol sp-rating">
      <span class="star active" data-number="5"></span><span class="star active" data-number="4"></span><span class="star active" data-number="3"></span><span class="star active" data-number="2"></span><span class="star active" data-number="1"></span>   </div>
    <span class="ajax-loader fa fa-spinner fa-spin"></span>
    <span class="voting-result">( 1 Rating )</span>
</dd>
          <div class="helix-social-share">
    <div class="helix-social-share-icon">
      <ul>
        
        <li>
          <div class="facebook" data-toggle="tooltip" data-placement="top" title="" data-original-title="Share On Facebook">

            <a class="facebook" onclick="window.open('http://www.facebook.com/sharer.php?u=http://senvietweb.com/demo/senvietdeal/index.php/huong-dan-thanh-toan/post-formats/standard-post-format.html','Facebook','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://www.facebook.com/sharer.php?u=http://senvietweb.com/demo/senvietdeal/index.php/huong-dan-thanh-toan/post-formats/standard-post-format.html">

              <i class="fa fa-facebook"></i>
            </a>

          </div>
        </li>
        <li>
          <div class="twitter" data-toggle="tooltip" data-placement="top" title="" data-original-title="Share On Twitter">
            
            <a class="twitter" onclick="window.open('http://twitter.com/share?url=http://senvietweb.com/demo/senvietdeal/index.php/huong-dan-thanh-toan/post-formats/standard-post-format.html&amp;text=Pellentesque%20Habitant%20Morbi%20Tristique','Twitter share','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://twitter.com/share?url=http://senvietweb.com/demo/senvietdeal/index.php/huong-dan-thanh-toan/post-formats/standard-post-format.html&amp;text=Pellentesque%20Habitant%20Morbi%20Tristique">
              <i class="fa fa-twitter"></i>
            </a>

          </div>
        </li>
        <li>
          <div class="google-plus">
            <a class="gplus" data-toggle="tooltip" data-placement="top" title="" onclick="window.open('https://plus.google.com/share?url=http://senvietweb.com/demo/senvietdeal/index.php/huong-dan-thanh-toan/post-formats/standard-post-format.html','Google plus','width=585,height=666,left='+(screen.availWidth/2-292)+',top='+(screen.availHeight/2-333)+''); return false;" href="https://plus.google.com/share?url=http://senvietweb.com/demo/senvietdeal/index.php/huong-dan-thanh-toan/post-formats/standard-post-format.html" data-original-title="Share On Google Plus">
            <i class="fa fa-google-plus"></i></a>
          </div>
        </li>
        
        <li>
          <div class="linkedin">
            <a class="linkedin" data-toggle="tooltip" data-placement="top" title="" onclick="window.open('http://www.linkedin.com/shareArticle?mini=true&amp;url=http://senvietweb.com/demo/senvietdeal/index.php/huong-dan-thanh-toan/post-formats/standard-post-format.html','Linkedin','width=585,height=666,left='+(screen.availWidth/2-292)+',top='+(screen.availHeight/2-333)+''); return false;" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=http://senvietweb.com/demo/senvietdeal/index.php/huong-dan-thanh-toan/post-formats/standard-post-format.html" data-original-title="Share On Linkedin">
              
            <i class="fa fa-linkedin-square"></i></a>
          </div>
        </li>
      </ul>
    </div>    
  </div>  --><!-- /.helix-social-share -->














      </div>
          </div>


          <div class="jshop_list_product_related">
    <div class="related_header"><span>Sản Phẩm Khác</span></div>
    <div class="list_related">

      <?php foreach($news_list as $row) : ?>
      <div class="jshop_related">
        <div class="product productitem_119">
          <div class="item-wrap">
            <div class="item-image">
              <a class="img" href="<?php echo base_url('news/view/'.$row->id)?>" title="<?=$row->title?>">
                <img  src="<?php echo base_url('/upload/news/'.$row->image_link)?>" alt="<?=$row->title?>" title="<?=$row->title?>">
              </a>
              
            </div>
                
            <div class="item-info">
              <h3 class="item-title">
                 <a class="img" href="<?php echo base_url('news/view/'.$row->id)?>" title="<?=$row->title?>">
                  <?=$row->title?>                     
                </a>
              </h3>
              
              <div class="extra_fields"></div>
                <div class="main-price">
                  <div class = "item-price">
                    <span class="price">
                      <?php 
                          if(strlen($row->intro) < 20){
                              echo $row->intro;
                          }else{
                            echo mb_substr($row->intro,0,100,'utf8').'...';
                          }
                      ?>         
                    </span>
                  </div>
              
                  
                </div>
            </div>
          </div>
        </div>
      </div>  

      <?php endforeach?>  
    </div>
    </div> 
<script type="text/javascript">

  jQuery(document).ready(function($) {

    jQuery(".list_related").owlCarousel({
    autoPlay: 3000, //Set AutoPlay to 3 seconds
    items : 1,
    //Pagination
    pagination : false,
    paginationNumbers: false,
    nav: true,
    loop: false,
    margin: 30,
    responsive:{
      767:{
        items: 2,
      },
      992:{
        items: 3,
      },
      1200:{
        items: 4,
      },
    }
    });
  });

</script>


  
</article>
</div></div></div></div></section>

<style type="text/css">
  
  .owl-prev{
    padding:10px;
    position:absolute;
    top:-50px;
    right:60px;
    background: #db6516;
    color:#fff;
    border-radius: 20px 5px 5px 20px;
  }
  .owl-next{
    padding:10px;
    position:absolute;
    color:#fff;
    top:-50px;
    right:0;
    background: #db6516;
    border-radius: 5px 20px 20px 5px;
  }
</style>








