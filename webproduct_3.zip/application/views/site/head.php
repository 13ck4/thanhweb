
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
            <!-- head -->
      <base href="http://senvietweb.com/demo/senvietdeal/" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="keywords" content="Thiết kế website chuyên nghiệp - Thiết kế logo, banner - quản lý website - quảng cáo facebook adword và seo website hạng top google. Công ty TNHH Thương mại công nghệ Sen Việt là một trong những đơn vị đi đầu trong lĩnh vực công nghệ, thông tin, hệ thống phân phối sản phầm website" />
  <meta name="description" content="Thiết kế website chuyên nghiệp - Thiết kế logo, banner - quản lý website - quảng cáo facebook adword và seo website hạng top google. Công ty TNHH Thương mại công nghệ Sen Việt là một trong những đơn vị đi đầu trong lĩnh vực công nghệ, thông tin, hệ thống phân phối sản phầm website" />
  <meta name="generator" content="Joomla! - Open Source Content Management" />
  <title>Mua Hàng OnLine | Shop đa thời trang cao cấp | Giảm ngay 30% khi mua sản phẩm</title>
  
  
  
  
  
  <link href="<?php echo public_url('site/font-awesome/css/font-awesome.css') ?>" rel="stylesheet" type="text/css" />
  <!-- <link href="/luat/senvietdeal/components/com_sppagebuilder/assets/css/animate.min.css" rel="stylesheet" type="text/css" /> -->
  <link href="<?php echo public_url('site/css/sppagebuilder.css')?>" rel="stylesheet" type="text/css" />
  <!-- <link href="/luat/senvietdeal/components/com_sppagebuilder/assets/css/sppagecontainer.css" rel="stylesheet" type="text/css" />
  <link href="/luat/senvietdeal/templates/sj_topdeal/css/font-awesome.min.css" rel="stylesheet" type="text/css" /> -->
  <link href="<?php echo public_url('site/css/megamenu.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo public_url('site/css/sj-megamenu.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo public_url('site/css/sj-megamenu-mobile.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo public_url('site/css/sj-megamenu-vertical.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo public_url('site/css/mod_sj_js_extraslider.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo public_url('site/css/extraslider-css3.css')?>" rel="stylesheet" type="text/css" />
  <!-- <link href="<?php echo public_url('site/css/sj-theme.css')?>" rel="stylesheet" type="text/css" /> -->


  <link href="<?php echo public_url('site/css/isotope.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo public_url('site/css/sj-reslisting.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo public_url('site/css/style.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo public_url('site/css/css3.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo public_url('site/css/animate.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo public_url('site/css/owl.carousel.css')?>" rel="stylesheet" type="text/css" />


  <link href="//fonts.googleapis.com/css?family=Roboto:100,100italic,300,300italic,regular,italic,500,500italic,700,700italic,900,900italic&amp;subset=latin,greek-ext" rel="stylesheet" type="text/css" />

  <link href="<?php echo public_url('site/css/bootstrap.min.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo public_url('site/css/jquery.fullpage.min.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo public_url('site/css/owl.carousel.css')?>" rel="stylesheet" type="text/css" />
  <!-- <link href="/luat/senvietdeal/templates/sj_topdeal/css/legacy.css" rel="stylesheet" type="text/css" /> -->
  <link href="<?php echo public_url('site/css/preset4.css')?>" rel="stylesheet" type="text/css" class="preset" />
  <link href="<?php echo public_url('site/css/pagebuilder.css')?>" rel="stylesheet" type="text/css" />
  <!-- <link href="/luat/senvietdeal/media/com_acymailing/css/module_default.css?v=1486546328" rel="stylesheet" type="text/css" /> -->
  <link href="<?php echo public_url('site/css/shortcodes.css')?>" rel="stylesheet" type="text/css" />
  

  
<script type="text/javascript" src="<?php echo public_url()?>/js/jquery/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo public_url()?>/js/jquery/jquery-ui.min.js"></script>
  <style type="text/css">
#sp-page-builder #yt_slideshow{margin:10px 0px 0px 0px;padding:0px 0px 30px 0;}

#sp-page-builder #scoll1{margin:0px 0px 0px 0px;padding:0 0px 0 0px;}
#sppb-addon-1499069827915 {
margin: 0 0 30px 0;
}

#sppb-addon-1499069827923 {
margin: 0 0 30px 0;
}

#sp-page-builder #scoll2{margin:0px 0px 0px 0px;padding:0 0px 0 0px;}
#sppb-addon-1499069827920 {
margin: 0 0 30px 0;
}

#sp-page-builder #scoll3{margin:0px 0px 0px 0px;padding:0 0px 0 0px;}
#sppb-addon-1499069827928 {
margin: 0 0 30px 0;
}

#sp-page-builder #scoll4{margin:0px 0px 0px 0px;padding:0 0px 0 0px;}
#sppb-addon-1499069827933 {
margin: 0 0 30px 0;
}

#sp-page-builder #scoll5{margin:0px 0px 0px 0px;padding:0 0px 0 0px;}
#sppb-addon-1499069827938 {
margin: 0 0 30px 0;
}

#sp-page-builder #section-id-1497596545411{margin:0px 0px 0px 0px;padding:0 0px 30px 0px;}
#sp-page-builder #block-scoll{margin:0px 0px 0px 0px;padding:0 0px 22px 0px;}
#sp-page-builder #section-id-1497881723727{margin:0px 0px 0px 0px;padding:0 0px 30px 0px;}
body{font-family:Roboto, sans-serif; font-weight:normal; }
h1{font-family:Roboto, sans-serif; font-weight:100; }
#sp-header-top{ background-color:#ffffff; }
#sp-block-acymailling{ background-color:#ffffff; }
#sp-block-bottom-2{ background-color:#ffffff; }
#sp-footer{ background-color:#060d11; }
div.mod_search35 input[type="search"]{ width:auto; }
  </style>
  <script type="application/json" class="joomla-script-options new">{"joomla.jtext":{"COM_SPPAGEBUILDER_FRONTEND_EDITOR":"Frontend Editor","COM_SPPAGEBUILDER_PREVIEW":"Preview","COM_SPPAGEBUILDER_APPLY":"Apply","COM_SPPAGEBUILDER_CANCEL":"Cancel","COM_SPPAGEBUILDER_MEDIA_MANAGER":"Media Manager","COM_SPPAGEBUILDER_MEDIA_MANAGER_UPLOAD_FILES":"Upload Files","COM_SPPAGEBUILDER_MEDIA_MANAGER_CLOSE":"Close Modal","COM_SPPAGEBUILDER_MEDIA_MANAGER_INSERT":"Insert","COM_SPPAGEBUILDER_MEDIA_MANAGER_SEARCH":"Search","COM_SPPAGEBUILDER_MEDIA_MANAGER_CANCEL":"Cancel","COM_SPPAGEBUILDER_MEDIA_MANAGER_DELETE":"Delete","COM_SPPAGEBUILDER_MEDIA_MANAGER_CONFIRM_DELETE":"You are about to permanently delete this item. 'Cancel' to stop, 'OK' to delete.","COM_SPPAGEBUILDER_MEDIA_MANAGER_LOAD_MORE":"Load More","COM_SPPAGEBUILDER_MEDIA_MANAGER_UNSUPPORTED_FORMAT":"File format not supported.","COM_SPPAGEBUILDER_MEDIA_MANAGER_BROWSE_MEDIA":"Browse Media","COM_SPPAGEBUILDER_MEDIA_MANAGER_BROWSE_FOLDERS":"Browse Folders","COM_SPPAGEBUILDER_MEDIA_MANAGER_CREATE_FOLDER":"New Folder","COM_SPPAGEBUILDER_ADDON_ICON_SELECT":"Select Icon","COM_SPPAGEBUILDER_MEDIA_MANAGER_ENTER_DIRECTORY_NAME":"Please enter the name of the directory which should be created.","COM_SPPAGEBUILDER_MEDIA_MANAGER_MEDIA_UPLOADING":"Uploading","COM_SPPAGEBUILDER_MEDIA_MANAGER_UPLOAD_FAILED":"Upload Failed","COM_SPPAGEBUILDER_MEDIA_MANAGER_MEDIA_LARGE":"This file is too large to upload.","COM_SPPAGEBUILDER_MEDIA_MANAGER_FILE_NOT_SUPPORTED":"File not supported","COM_SPPAGEBUILDER_ROW_OPTIONS":"Row Options","COM_SPPAGEBUILDER_ADD_NEW_ROW":"Add New Row","COM_SPPAGEBUILDER_DUPLICATE_ROW":"Duplicate row","COM_SPPAGEBUILDER_DISABLE_ROW":"Disable Row","COM_SPPAGEBUILDER_ENABLE_ROW":"Enable Row","COM_SPPAGEBUILDER_COPY_ROW":"Copy Row","COM_SPPAGEBUILDER_ROW_COPIED":"Copied","COM_SPPAGEBUILDER_PASTE_ROW":"Paste Row","COM_SPPAGEBUILDER_DELETE_ROW":"Delete Row","COM_SPPAGEBUILDER_ROW_TOGGLE":"Toggle Row","COM_SPPAGEBUILDER_DELETE_ROW_CONFIRMATION":"Do you really want to delete this row?","COM_SPPAGEBUILDER_ROW_COLUMNS_MANAGEMENT":"Add\/Manage Columns","COM_SPPAGEBUILDER_ROW_COLUMNS_CUSTOM":"Custom","COM_SPPAGEBUILDER_ROW_COLUMNS_GENERATE":"Generate","COM_SPPAGEBUILDER_IMPORT_PAGE":"Import","COM_SPPAGEBUILDER_IMPORT_PAGE_ALT":"Import","COM_SPPAGEBUILDER_EXPORT_PAGE":"Export","COM_SPPAGEBUILDER_PAGE_TEMPLATES":"Page Templates","COM_SPPAGEBUILDER_UNDO":"Undo","COM_SPPAGEBUILDER_REDO":"Redo","COM_SPPAGEBUILDER_SAVE":"Save","COM_SPPAGEBUILDER_ROW_COLUMNS_OPTIONS":"Column Options","COM_SPPAGEBUILDER_DELETE_COLUMN":"Delete Column","COM_SPPAGEBUILDER_ADD_NEW_ADDON":"Add New Addon","COM_SPPAGEBUILDER_ADDON":"Addon","COM_SPPAGEBUILDER_DELETE_ADDON":"Delete Addon","COM_SPPAGEBUILDER_DUPLICATE_ADDON":"Clone Addon","COM_SPPAGEBUILDER_EDIT_ADDON":"Edit Addon","COM_SPPAGEBUILDER_ADDONS_LIST":"Addons List","COM_SPPAGEBUILDER_ALL":"All","COM_SPPAGEBUILDER_MODAL_CLOSE":"Close Modal","COM_SPPAGEBUILDER_DISABLE_COLUMN":"Disable Column","COM_SPPAGEBUILDER_ENABLE_COLUMN":"Enable Column","COM_SPPAGEBUILDER_YES":"Yes","COM_SPPAGEBUILDER_NO":"No","COM_SPPAGEBUILDER_PAGE_TEMPLATES_LIST":"Templates List","COM_SPPAGEBUILDER_PAGE_TEMPLATE_LOAD":"Load","COM_SPPAGEBUILDER_ENABLE_ADDON":"Enable Addon","COM_SPPAGEBUILDER_DISABLE_ADDON":"Disable Addon","COM_SPPAGEBUILDER_ADDON_PARENT_COLUMN":"Parent Column","COM_SPPAGEBUILDER_ADD_NEW_INNER_ROW":"Add Inner Row","COM_SPPAGEBUILDER_MOVE_COLUMN":"Move Column"}}</script>

  <script src="<?php echo public_url('site/js/core.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/jquery.min.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/jquery-noconflict.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/jquery-migrate.min.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/megamenu.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/jquery.easing.1.3.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/jcarousel.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/jquery.isotope.js')?>" type="text/javascript"></script>


  <script src="<?php echo public_url('site/js/owl.carousel.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/sppagebuilder.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/bootstrap.min.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/owl.carousel.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/jquery.touchSwipe.min.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/jquery.prettyPhoto.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/jquery.sticky.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/jquery.fullpage.min.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/main.js')?>" type="text/javascript"></script>


  <script src="<?php echo public_url('site/js/custom.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/html5fallback.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/acymailing_module.js')?>" type="text/javascript" async="async"></script>
  <script src="<?php echo public_url('site/js/mootools-core.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/jquery.media.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/functions.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/validateForm.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/prettify.js')?>" type="text/javascript"></script>
  <script src="<?php echo public_url('site/js/shortcodes.js')?>" type="text/javascript"></script>

  <script src="<?php echo public_url('site/js/jquery.lightbox.js') ?>" type="text/javascript"></script>
  <script type="text/javascript">

var sp_preloader = '0';

var sp_gotop = '1';

var sp_offanimation = 'default';

  if(typeof acymailing == 'undefined'){
          var acymailing = Array();
        }
        acymailing['NAMECAPTION'] = 'Name';
        acymailing['NAME_MISSING'] = 'Please enter your name';
        acymailing['EMAILCAPTION'] = 'Nhập Email của bạn!';
        acymailing['VALID_EMAIL'] = 'Please enter a valid e-mail address';
        acymailing['ACCEPT_TERMS'] = 'Please check the Terms and Conditions';
        acymailing['CAPTCHA_MISSING'] = 'The captcha is invalid, please try again';
        acymailing['NO_LIST_SELECTED'] = 'Please select the lists you want to subscribe to';
    
  </script>
  <meta content="website" property="og:type"/>
  <meta content="<?php echo base_url() ?>" property="og:url" />
  <meta content="Mua Hàng OnLine | Shop đa thời trang cao cấp | Giảm ngay 30% khi mua sản phẩm" property="og:title" />
  <link href="<?php echo base_url() ?>" rel="alternate" hreflang="x-default" />

        