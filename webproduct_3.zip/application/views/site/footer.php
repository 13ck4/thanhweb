<section id="sp-block-bottom-2"><div class="container"><div class="row"><div id="sp-position4" class="col-sm-6 col-md-6"><div class="sp-column "><div class="sp-module "><div class="sp-module-content">

<div class="custom">
    <div class="logo-bottom">
<div class="img-logo"><img src="<?=public_url('site/images/logo.jpg')?>" alt=""></div>
<div class="img-logo">Gửi trọn niềm tin trong thế giới của bạn -&nbsp;Thế giới thời trang cao cấp </div>
<div class="content">
<ul>
<li class="address">Địa chỉ: 23 Mã Lò, Phường Tân Tạo, Quận Bình Tân</li>
<li class="phone">Số điện thoại: <a href="tel:01693779225" rel="alternate">0169.377.9225</a></li>
<li class="email">Hộp thư điện tử: <a href="mailto:send:luatnguyen13ck4@gmail.com" rel="alternate">luatnguyen13ck4@gmail.com</a></li>
</ul>
</div>
</div></div>
</div></div></div></div><div id="sp-position3" class="col-sm-6 col-md-6"><div class="sp-column "><div class="sp-module "><div class="sp-module-content"><div id="mod_sl_fbfanbox">
	<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FUnofficial-abc-414435902287344%2F&tabs=timeline&width=340&height=256&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=843194329198115" width="400" height="250" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>    
</div>

</div></div></div></div></div></div>
</section>

<footer id="sp-footer"><div class="container"><div class="row"><div id="sp-footer1" class="col-sm-8 col-md-8"><div class="sp-column "><span class="sp-copyright">© 2018 <a href="<?php echo base_url() ?>">Nguyễn Ngọc Luật</a>. Bản quyền này thuộc về <a href="<?php echo base_url() ?>">Nguyễn Ngọc Luật</a></span></div></div><div id="sp-footer2" class="col-sm-4 col-md-4"><div class="sp-column "><div class="sp-module "><div class="sp-module-content">

<div class="custom">
    <div class="payments"><img src="<?php echo public_url('site/images/pay.png')?>" alt=""></div></div>
</div></div></div></div></div></div>
</footer>