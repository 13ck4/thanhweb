<footer style="width:100%;float:left;">
<!-- The box-footer-->		        
 <div id="footer_text" style="width:20%;float: left;margin-right: 10px;"> <!-- The footer_text --> 
     
         <ul class="menu_top">
              <li class="active index-li"><a style="line-height: 30px !important;" href="<?php echo base_url() ?>"><b>Trang chủ </b></a></li>
              <li class=""><a style="line-height: 30px !important;" href="<?php echo site_url('gioi-thieu') ?>"><b>Giới thiệu</b></a></li>
              <!-- <li class=""><a href="info/view/2.html">Hướng dẫn</a></li> -->
              <li class=""><a style="line-height: 30px !important;" href="<?php echo site_url('san-pham')?>"><b>Sản phẩm</b></a></li>
              <li class=""><a style="line-height: 30px !important;" href="<?php echo site_url('tin-tuc')?>"><b>Tin tức</b></a></li>
             <!--  <li class=""><a href="video.html">Video</a></li> -->
              <li class=""><a style="line-height: 30px !important;" href="<?php echo site_url('lien-he')?>"><b>Liên hệ</b></a></li>

              <li class=""><a style="line-height: 30px !important;" href="<?php echo site_url('dang-ky') ?>"><b>Đăng ký</b></a></li>
              <li class=""><a style="line-height: 30px !important;" href="<?php echo site_url('dang-nhap') ?>"><b>Đăng nhập</b></a></li>
              
          </ul>



  
	 
 </div><!-- End footer_text -->
 
  <div id="footer_face" style="width:20%;float: left;text-align: left;margin-right: 40px;">  <!-- The footer_face -->            
        <h2>Tin Tức</h2>
        <br/>
        <?php foreach($news_list as $row) : ?>

        <div style="width:100%;float: left;margin-bottom: 30px;">
	         <div class="product_img" style=" width:20%;float: left;" >
	               <a href="<?php echo base_url('news/view/'.$row->id)?>" title="<?=$row->title?>">
	                  <img width="35px" height="40px" style="border-radius: 7px" src="<?php echo base_url('/upload/news/'.$row->image_link)?>" alt="<?=$row->title?>" title="<?=$row->title?>">
	              </a>
	         </div>
	         <h4 style="width:80%;float: left;">
	               <a href="<?php echo base_url('news/view/'.$row->id)?>" title="<?=$row->title?>">
	                    <?=$row->title?>                     
	                </a>
	          </h4>
	    </div>
	    
	    <br />
        <?php endforeach ?>

  </div><!-- End footer_face -->

  <div id="footer_face" style="width:20%;float: left;margin-right: 10px;"> 
  		<h2>Bản Đồ</h2>
  		 <!-- The footer_face -->            
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15679.686145320413!2d106.69398039783822!3d10.740530668788926!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752fa4925c8357%3A0xe90fc829249751fb!2zQ8O0bmcgVHkgVG5oaCBUaMawxqFuZyBN4bqhaSBE4buLY2ggVuG7pSBUaMOhaSBOZ-G7jWMgWMawxqFuZw!5e0!3m2!1svi!2s!4v1458284262572" width="222" height="350" frameborder="0" style="border:0" allowfullscreen=""></iframe> 
  </div>

  
  <div id="footer_faces" style="width:20%;float: left; margin-right: 10px;">  <!-- The footer_face -->  
  		<h2>Liên Hệ</h2>          
        <div class="c-container c-last">
          <div class="c-content-title-1">
              <div class="c-line-left hide">
              </div>
              <p>
                  Hãy liên lạc với chúng tôi để được tư vấn và hỗ trợ tốt nhất
              </p>
          </div>
          <ul class="c-socials">
              <li>
                  <a href="https://www.facebook.com/H%E1%BB%87-Th%E1%BB%91ng-Karaoke-Chuy%C3%AAn-Nghi%E1%BB%87p-Prosing-261332110891810/"><i class="icon-social-facebook"></i></a>
              </li>
              <li>
                  <a href="https://twitter.com/login"><i class="icon-social-twitter"></i></a>
              </li>
              <li>
                  <a href="https://www.youtube.com/channel/UCTKCt5zAGlvWcNTK6Doo51w"><i class="icon-social-youtube"></i></a>
              </li>
              <li>
                  <a href="https://www.tumblr.com/login"><i class="icon-social-tumblr"></i></a>
              </li>
          </ul>
          <ul class="c-address">
              <li>
             <p>     <i class="icon-pointer c-theme-font"></i> Lầu 1, 24 Đường số 1A, KDC Trung Sơn Bình Hưng, Bình Chánh, TP.HCM</p>
              </li>
              <li>
                 <p> <i class="icon-call-end c-theme-font"></i> (84)933.85.85.88 Mr Xương</p>

              </li>
               <li>
                 <p> <i class="icon-call-end c-theme-font"></i> Liên hệ Markerting:</p>
                     <p> (84)988.45.22.57 Ms Mai</p>
              </li>
              <li>
                <p>  <i class="icon-call-end c-theme-font"></i>Liên Hệ Hotline: </p>
                       <p>(84-8) 66 74 73 76 - (84) 909.37.22.28 - (84) 909.14.52.28</p>
              </li>
              <li>
              <p>    <i class="icon-envelope c-theme-font"></i> prosing.co@gmail.com</p>
              </li>
              <li>
                 <p> <i class="icon-envelope c-theme-font"></i> support@prosing.com.vn</p>
              </li>
          </ul>
      </div>  
  </div>
</footer>

 <div class="clear"></div><!-- clear float --> 		        <!-- End box-footer -->

