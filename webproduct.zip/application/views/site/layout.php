<!DOCTYPE html>
<html>
	<head>
		<?php $this->load->view('site/head.php');?>
	</head>
	<body>
		<a href="#" id="back_to_top">
		   	<img src="<?php echo public_url()?>site/images/top.png" />
	  	</a>
	  	<!-- the wraper -->
      	<div class="wraper">
	        <!-- the header -->
		    <div class='header'>
		      	<?php $this->load->view('site/header.php');?>
		    </div>
		    <div id="container">
		      	<div class='left'>
		      		<?php $this->load->view('site/left.php', $this->data);?>
		      	</div>
		      	<div class="content"> 
		      		<?php if(isset($message)) : ?>
		      			<p style="color:red;"><?php echo $message; ?></p>
		      		<?php endif?>
		      		<?php $this->load->view($temp, $this->data);?>
		      	</div>
		      	<div class="right">
		      		<?php $this->load->view('site/right.php', $this->data);?>
		      	</div>

		    </div>
			
				<img src="<?php echo public_url()?>/site/images/bank.png"> 
		  	
		  	<div class="footer">
		   		<?php $this->load->view('site/footer.php');?>
		   	</div>
	   	</div>
	</body>
</html>