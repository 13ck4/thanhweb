<!-- The Support -->
<div class="box-right">
    <div class="title tittle-box-right">
        <h2> Hỗ trợ trực tuyến </h2>
    </div>
    <div class="content-box">
         <!-- goi ra phuong thuc hien thi danh sach ho tro -->
         <div class="support">
	        <strong>Nguyễn Ngọc Luật </strong>				
			  
		 	<p>
		     		<img style="margin-bottom:-3px" src="<?php echo public_url()?>/site/images /phone.png"> 01693779225      
			</p>
			<p>
				<a rel="nofollow" href="mailto:hoangvantuyencnt@gmail.com">
				    <img style="margin-bottom:-3px" src="<?php echo public_url()?>/site/images /email.png"> Email: luatnguyen13ck4
			    </a>
			</p>
			<p>
				<a rel="nofollow" href="skype:luatnguyen13ck4">
				 	<img style="margin-bottom:-3px" src="<?php echo public_url()?>/site/images /skype.png"> Skype: luatnguyen13ck4
				</a>
			</p>	
		</div>	 
	</div>

 </div>
<!-- End Support -->

 <!-- The news -->
<div class="box-right">
    <div class="title tittle-box-right">
        <h2> Bài viết mới </h2>
    </div>
    <div class="content-box">
       <ul class="news">
        <?php foreach($news_list as $row) : ?>
            <li>
                <a href="<?php echo site_url('news/view/'.$row->id) ?>" title="<?=$row->title?>">
	                <img src="<?php echo base_url('upload/news/'.$row->image_link) ?>" width="20px" alt="<?=$row->title?>" title="<?=$row->title?>">
	                <?=$row->title?>
	            </a>
            </li>
		<?php endforeach ?>
        </ul>
</div>
</div>		<!-- End news -->

<!-- The Ads -->
<div class="box-right">
    <div class="title tittle-box-right">
        <h2> Quảng cáo </h2>
    </div>
    <div class="content-box">
        <a href="">
		     <img src="<?php echo public_url()?>/site/images /ads.png">
		</a>
    </div>
</div>
<!-- End Ads -->

 <!-- The Fanpage -->
<div class="box-right">
    <div class="title tittle-box-right">
        <h2> Fanpage </h2>
    </div>
    <div class="content-box">
          
         <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FUnofficial-abc-414435902287344%2F&tabs=timeline&width=340&height=256&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=843194329198115" width="190" height="300" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
       
    </div>
</div>
<!-- End Fanpage -->

 <!-- The Fanpage -->
<div class="box-right">
    <div class="title tittle-box-right">
        <h2> Thống kê truy cập </h2>
    </div>
    <div class="content-box">
        <center>
        <!-- Histats.com  START  (standard)-->
		<script type="text/javascript">document.write(unescape("%3Cscript src=%27http://s10.histats.com/js15.js%27 type=%27text/javascript%27%3E%3C/script%3E"));</script><script src="http://s10.histats.com/js15.js" type="text/javascript"></script>
		<a href="http://www.histats.com" target="_blank" title="hit counter"><script type="text/javascript">
		try {Histats.start(1,2138481,4,401,118,80,"00011111");
		Histats.track_hits();} catch(err){};
		</script><div id="histats_counter_453" style="display: block;"><a href="http://www.histats.com/viewstats/?sid=2138481&amp;ccid=401" target="_blank"><canvas id="histats_counter_453_canvas" width="119" height="81"></canvas></a></div></a>
		<noscript>&lt;a href="http://www.histats.com" target="_blank"&gt;&lt;img  src="http://sstatic1.histats.com/0.gif?2138481&amp;101" alt="hit counter" border="0"&gt;&lt;/a&gt;</noscript>
	    <!-- Histats.com  END  -->
		</center>                
    </div>
</div>
<!-- End Fanpage -->