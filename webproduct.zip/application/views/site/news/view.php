

<?php 
  $this->load->view('site/slide.php', $this->data);
?>
<div class="box-center"><!-- The box-center product-->
    <div class="tittle-box-center">
        <h2>Chi tiết Tin Tức</h2>
    </div>
    <br />
    
    <header class="clearfix">
    		<br />
    		<br />
			<b class="time left"><?=$news->created?></b>
		<br /><br />

			<h1 class="title_news_detail mb10">
				<?=$news->title?>
		 	</h1>
		 	<br />
		 	<h2 class="description"><?=$news->intro?></h2>
	</header>
	<br />
	<article class="content_detail fck_detail width_common block_ads_connect">
		<p class="Normal">
			<?=$news->content?>
		</p> 
	</article>

	<div class="tittle-box-center">
            <h2>Bạn Có thể Quan Tâm</h2>
      </div>
          <div class="box-content-center product"><!-- The box-content-center -->

            <?php foreach($news_list as $row) : ?>
              <div class="product_item">
                  
                 <div class="product_img">
                       <a href="<?php echo base_url('news/view/'.$row->id)?>" title="<?=$row->title?>">
                          <img src="<?php echo base_url('/upload/news/'.$row->image_link)?>" alt="<?=$row->title?>" title="<?=$row->title?>">
                      </a>
                 </div>
                 <h3>
                       <a href="<?php echo base_url('news/view/'.$row->id)?>" title="<?=$row->title?>">
                            <?=$row->title?>                     
                        </a>
                  </h3>

                  <p class="price">

                      <?php 
                          if(strlen($row->intro) < 20){
                              echo $row->intro;
                          }else{
                            echo mb_substr($row->intro,0,100,'utf8').'...';
                          }
                      ?>
                      
                  </p>
             </div>
              <?php endforeach?>
                <div class="clear"></div>
          </div><!-- End box-content-center -->

</div>