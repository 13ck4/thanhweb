	<div class="box-center"><!-- The box-center product-->
      <div class="tittle-box-center">
            <h2>Thông tin nhận hàng của thành viên</h2>
      </div>
      <div class="box-content-center product"><!-- The box-content-center -->
          <form enctype="multipart/form-data" action="" method="post" class="t-form form_action">

            <div class="form-row">
              <label class="form-label" for="param_email">Tổng tiền cần thanh toán:</label>
              <div class="form-item">
                  <b style="color: red;font-size: 22px"><?php echo number_format($total_amount) ?> đ</b>
              </div>
              <div class="clear"></div>
            </div>

            <div class="form-row">
              <label class="form-label" for="param_email">Email:<span class="req">*</span></label>
              <div class="form-item">
                <input type="text" value="<?php echo isset($user->email) ? $user->email : "" ?>" name="email" id="email" class="input">
                <div class="clear"></div>
                <div id="email_error" class="error"><?php echo form_error('email')?></div>
              </div>
              <div class="clear"></div>
            </div>
        
          <div class="form-row">
            <label class="form-label" for="param_name">Họ và tên:<span class="req">*</span></label>
            <div class="form-item">
              <input type="text" value="<?php echo isset($user->name) ? $user->name : "" ?>" name="name" id="name" class="input">
              <div class="clear"></div>
              <div id="name_error" class="error"><?php echo form_error('name')?></div>
            </div>
            <div class="clear"></div>
          </div>
          <div class="form-row">
            <label class="form-label" for="param_phone">Số điện thoại:<span class="req">*</span></label>
            <div class="form-item">
              <input type="text" value="<?php echo isset($user->phone) ? $user->phone : "" ?>" name="phone" id="phone" class="input">
              <div class="clear"></div>
              <div id="phone_error" class="error"><?php echo form_error('phone')?></div>
            </div>
            <div class="clear"></div>
          </div>
          
          <div class="form-row">
            <label class="form-label" for="param_address">Địa Chỉ Nhận Hàng:<span class="req">*</span></label>
            <div class="form-item">
              <textarea name="message" id="message" class="input"></textarea>
              <p>Nhập địa chỉ và thời gian nhận hàng</p>
              <div class="clear"></div>
              <div id="message_error" class="error"><?php echo form_error('message')?></div>
            </div>
            <div class="clear"></div>
          </div>
          
           <div class="form-row">
            <label class="form-label" for="param_address">Thanh toán qua:<span class="req">*</span></label>
            <div class="form-item">
                  <select name="payment">
                      <option value="">---- Chọn Hình Thức Thanh Toán ----</option>
                      <option value="offline">Thanh Toán Khi Nhận Hàng</option>
                      <option value="atcomputer">Giao dịch tại công ty</option>
                      <option value="atpostoffice">Giao dịch wa bưu điện</option>
                      
                  </select>
                 <!--  <div class="one-box">
  
                      <table>
                        <tbody>
                        <tr>
                          <td colspan="3" style="padding: 10px;">
                            Thời gian nhận hàng <select name="gio_nhan_hang">
                                        <option value="0">0</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                        <option value="13">13</option>
                                        <option value="14">14</option>
                                        <option value="15">15</option>
                                        <option value="16">16</option>
                                        <option value="17">17</option>
                                        <option value="18" selected="selected">18</option>
                                        <option value="19">19</option>
                                        <option value="20">20</option>
                                        <option value="21">21</option>
                                        <option value="22">22</option>
                                        <option value="23">23</option>
                                      </select>&nbsp;:&nbsp;<select name="phut_nhan_hang">
                                        <option value="0">0</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                        <option value="13">13</option>
                                        <option value="14">14</option>
                                        <option value="15">15</option>
                                        <option value="16">16</option>
                                        <option value="17">17</option>
                                        <option value="18">18</option>
                                        <option value="19">19</option>
                                        <option value="20">20</option>
                                        <option value="21">21</option>
                                        <option value="22">22</option>
                                        <option value="23">23</option>
                                        <option value="24">24</option>
                                        <option value="25">25</option>
                                        <option value="26">26</option>
                                        <option value="27">27</option>
                                        <option value="28">28</option>
                                        <option value="29">29</option>
                                        <option value="30" selected="selected">30</option>
                                        <option value="31">31</option>
                                        <option value="32">32</option>
                                        <option value="33">33</option>
                                        <option value="34">34</option>
                                        <option value="35">35</option>
                                        <option value="36">36</option>
                                        <option value="37">37</option>
                                        <option value="38">38</option>
                                        <option value="39">39</option>
                                        <option value="40">40</option>
                                        <option value="41">41</option>
                                        <option value="42">42</option>
                                        <option value="43">43</option>
                                        <option value="44">44</option>
                                        <option value="45">45</option>
                                        <option value="46">46</option>
                                        <option value="47">47</option>
                                        <option value="48">48</option>
                                        <option value="49">49</option>
                                        <option value="50">50</option>
                                        <option value="51">51</option>
                                        <option value="52">52</option>
                                        <option value="53">53</option>
                                        <option value="54">54</option>
                                        <option value="55">55</option>
                                        <option value="56">56</option>
                                        <option value="57">57</option>
                                        <option value="58">58</option>
                                      </select>&nbsp;&nbsp; 
                                      <input style="height: 25px;border-radius: 5px;" type="text" name="ngay_nhan_hang" id="datepicker"  class="txt_input_item_item" value="">
                          </td>
                        </tr>
                      </tbody></table>
                    </div> -->

                  <div class="clear"></div>
              <div id="payment_error" class="error"><?php echo form_error('payment')?></div>
            </div>
            <div class="clear"></div>
          </div>
          
          <div class="form-row">
            <label class="form-label">&nbsp;</label>
            <div class="form-item">
                    <input type="submit" name="submit" value="Thanh Toán" class="button">
            </div>
           </div>
            </form>
          <div class="clear"></div>
      </div><!-- End box-content-center -->
</div>
<script type="text/javascript">
  $( function() {
      $( "#datepicker" ).datepicker({dateFormat: 'dd-mm-yy'});
  } );

</script>

