<?php 
	$config = array(
		'admin' => array('index', 'add', 'edit', 'delete'),
		'user' => array('index', 'add', 'edit', 'delete'),
		'product' => array('index', 'add', 'edit', 'delete', 'del_all'),
		'catalog' => array('index', 'add', 'edit', 'delete', 'del_all'),
		'transaction' => array('index', 'add', 'edit', 'delete', 'del_all'),
		'news' => array('index', 'add', 'edit', 'delete', 'del_all'),
		'slide' => array('index', 'add', 'edit', 'delete', 'del_all'),
	);
	