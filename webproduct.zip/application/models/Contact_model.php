<?php 
	Class Contact_model extends MY_Model{
		var $table = 'info';
	}